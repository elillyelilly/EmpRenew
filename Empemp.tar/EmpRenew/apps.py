from django.apps import AppConfig


class EmprenewConfig(AppConfig):
    name = 'EmpRenew'
